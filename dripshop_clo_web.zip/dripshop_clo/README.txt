DRIPSHOP.CLO — sitio web estático

ARCHIVOS
- index.html: página y funcionalidades.
- products.json: catálogo extraído del PDF suministrado.
- assets/: fotografías suministradas en el ZIP.

PARA PROBAR
1. Descomprime dripshop_clo_web.zip.
2. Abre index.html en un navegador o súbelo a Vercel / Netlify.
3. Para publicar en Vercel: importa la carpeta/proyecto como sitio estático. No requiere build command ni base de datos.

FUNCIONES
- Catálogo de productos, búsqueda, filtros por marca/talla y orden por precio.
- Ficha de producto con selección de talla y cantidad.
- Bolsa/carrito y envío del pedido a WhatsApp.
- Enlaces a Instagram y TikTok.
- Métodos de pago informados: Nequi, Llaves y Bancolombia.

IMPORTANTE
- Se muestra el precio de venta COLOMBIA del PDF como precio público predeterminado.
- El PDF también contiene precio de venta CALI. Si la tienda debe mostrar ese precio, cambia el campo "price" de cada producto en products.json por su "caliPrice".
- El sitio no procesa pagos en línea ni confirma inventario en tiempo real. La talla, disponibilidad, envío y pago se confirman por WhatsApp.
- Revisa el emparejamiento de fotos y referencias antes de publicar; el catálogo original tiene algunas referencias con nombres/ortografía diferentes a los nombres de las imágenes.
